package edu.stevens.cs548.clinic.domain;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2017-10-10T10:00:51.351-0400")
@StaticMetamodel(SurgeryTreatment.class)
public class SurgeryTreatment_ extends Treatment_ {
	public static volatile SingularAttribute<SurgeryTreatment, Date> date;
}
